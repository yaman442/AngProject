import { Component } from '@angular/core';

@Component({
  selector: 'app-to-do',
  templateUrl: './to-do.component.html',
  styleUrls: ['./to-do.component.css']
})


export class ToDoComponent {
  selectedItem: any={};
  showViewItem: boolean = false;

  viewItem(item: any) {
    this.showEditItem = false;
    this.selectedItem = item;
    this.showViewItem = true;
  }


  editedItem: any = {};
  showEditItem: boolean = false;

  editItem(item: any) {
    this.showViewItem = false;
    this.editedItem = item;
    this.showEditItem = true;
  }



  saveItem() {
    this.selectedItem = this.editedItem;
  }

    todoList = [
    {
      id: 1,
      name: "Go to school",
      description: "Go to class and see what we are learning today",
      category: "Education",
      dueDate: "12-01-2022",
      status: "In progress"
    },
    {
      id: 2,
      name: "Gym",
      description: "Go to the gym",
      category: "Health",
      dueDate: "Recurring",
      status: "Not Started"
    },
    {
      id: 3,
      name: "See Freinds",
      description: "Spend some time with friends so they dont get mad, after finals",
      category: "Lifestyle",
      dueDate: "12-16-2022",
      status: "Not Started"
    },
    {
      id: 4,
      name: "Go Shopping",
      description: "I have to buy groceries to make food and buy a present",
      category: "Lifestyle",
      dueDate: "12-10-2022",
      status: "Not Started"
    },
    {
      id: 5,
      name: "Make Lunch",
      description: "Make Lunch so I dont get hungry during the day",
      category: "Lifestyle",
      dueDate: "12-10-2022",
      status: "Completed"
    },
    {
      id: 6,
      name: "Make Dinner",
      description: "Make Dinner so I dont get hungry at night",
      category: "Lifestyle",
      dueDate: "12-10-2022",
      status: "Completed"
    },
    {
      id: 7,
      name: "Homework",
      description: "Do homework and study",
      category: "Education",
      dueDate: "12-11-2022",
      status: "In Progress"
    },
    {
      id: 8,
      name: "Soccer Game",
      description: "This is the second item on the to-do list",
      category: "Health",
      dueDate: "12-14-2022",
      status: "Completed"
    },
    {
      id: 9,
      name: "Go to Birthday Party",
      description: "Go to nieces Birth Party",
      category: "Family",
      dueDate: "12-14-2022",
      status: "Not Started"
    },
    {
      id: 10,
      name: "Make bed",
      description: "Make bed after I wake up",
      category: "Lifestyle",
      dueDate: "Recurring",
      status: "Completed"
    }
  ];

  deleteItem(item:any) {
    this.todoList = this.todoList.filter(i => i !== item);
  }
}
